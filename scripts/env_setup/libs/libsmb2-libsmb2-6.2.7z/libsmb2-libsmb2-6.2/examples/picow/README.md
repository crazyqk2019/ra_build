# Pico W sample
This is the smb-ls-sync.c example adapted to run on a Pico W.  You will need the Pico-SDK and FreeRTOS-Kernel installed for this to work.  See the CMakeLists.txt file - there's some user configuration needed before the sample can be compiled and run.
