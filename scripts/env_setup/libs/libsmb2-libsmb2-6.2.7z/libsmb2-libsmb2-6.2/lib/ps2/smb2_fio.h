/*
  SMB2MAN
  Ronnie Sahlberg <ronniesahlberg@gmail.com> 2021
  André Guilherme <andregui17@outlook.com> 2023-2024

  Based on SMBMAN:
  Copyright 2009-2010, jimmikaelkael
  Licenced under Academic Free License version 3.0
*/
#ifndef __SMB2_FIO_H__
#define __SMB2_FIO_H__

int SMB2_initdev(void);

#endif
