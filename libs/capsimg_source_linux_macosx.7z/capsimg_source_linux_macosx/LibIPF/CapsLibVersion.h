#ifndef CAPSLIBVERSION_H
#define CAPSLIBVERSION_H

#define CAPS_LIB_RELEASE  5
#define CAPS_LIB_REVISION 1

#endif
