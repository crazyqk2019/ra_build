# Pico W config files
These files should be seen as samples and you can start with these or use your own.  They are here so that the examples/picow sample will compile and build.  These have not been tuned in any way, other than to let libsmb2 compile with the Pico W, FreeRTOS and lwip.
